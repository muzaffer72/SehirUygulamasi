package com.sikayetvar.sikayet_var

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
