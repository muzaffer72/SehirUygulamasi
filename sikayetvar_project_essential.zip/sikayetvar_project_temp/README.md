<<<<<<< HEAD
# ŞikayetVar - Belediye ve Valilik Şikayet/Öneri Platformu
=======
# workspace 
>>>>>>> c1e634eaadf087023abc75b94de64b0ecb1c4a18

[![Flutter](https://img.shields.io/badge/Flutter-2.0+-blue.svg)](https://flutter.dev/)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-10.0+-blue.svg)](https://www.postgresql.org/)
[![PHP](https://img.shields.io/badge/PHP-8.0+-blue.svg)](https://www.php.net/)
[![Node.js](https://img.shields.io/badge/Node.js-14.0+-blue.svg)](https://nodejs.org/)

## Proje Tanımı

ŞikayetVar, vatandaşların yerel yönetimlerle (belediyeler ve valilikler) etkileşime geçebileceği kapsamlı bir mobil platformdur. Bu platform, vatandaşların sorunlarını bildirme, çözüm takibi yapma ve yerel yönetimlerin performansını değerlendirme imkanı sunar.

## Özellikler

- **Şikayet/Öneri Gönderimi**: Vatandaşlar şehir ve ilçe bazlı şikayet ve önerilerini iletebilir
- **Instagram Benzeri Sosyal Yapı**: Kullanıcılar şikayetleri beğenebilir, yorum yapabilir ve paylaşabilir
- **Oyunlaştırma**: Puan sistemi ve seviyelerle kullanıcı katılımını artırma
- **Çok Dilli Destek**: Türkçe, İngilizce ve diğer dil seçenekleri
- **Şehir Profilleri**: Her şehir için detaylı bilgi, hizmetler ve projeler
- **Ödül Sistemi**: Belediyelerin problem çözme oranlarına göre ödüllendirilmesi
- **Konum Bazlı Filtreleme**: Kullanıcıların bulundukları bölgeye ait içerikleri görüntülemesi
- **Anket/Oylama Sistemi**: Şehir ve ülke çapında anket düzenleme

## Ekran Görüntüleri

![Uygulama Ana Ekranı](assets/screenshots/home.png)
![Şehir Profili](assets/screenshots/city_profile.png)
![Şikayet Detayı](assets/screenshots/complaint_detail.png)

## Teknolojiler

### Mobil Uygulama
- Flutter/Dart
- Provider State Management
- Google Maps API
- Firebase Messaging

### Backend/API
- Node.js
- Express.js
- PostgreSQL
- Drizzle ORM

### Admin Panel
- PHP
- JavaScript
- Bootstrap 5
- Chart.js

## Kurulum

Tam kurulum talimatları için [talimatlar.txt](talimatlar.txt) dosyasına bakın.

### Hızlı Başlangıç

1. Gerekli bağımlılıkları yükleyin
2. Veritabanını oluşturun
3. Admin paneli yapılandırın
4. Flutter uygulamasını çalıştırın

## Katkı Sağlama

1. Bu repository'yi fork edin
2. Feature branch oluşturun (`git checkout -b feature/amazing-feature`)
3. Değişikliklerinizi commit edin (`git commit -m 'feat: Add some amazing feature'`)
4. Branch'inize push edin (`git push origin feature/amazing-feature`)
5. Pull Request oluşturun

## Lisans

Bu proje MIT lisansı altında lisanslanmıştır - ayrıntılar için [LICENSE](LICENSE) dosyasına bakın.

## İletişim

Proje ekibi - [destek@sikayetvar.com](mailto:destek@sikayetvar.com)

Proje Linki: [https://github.com/yourusername/sikayetvar-platform](https://github.com/yourusername/sikayetvar-platform)