package com.sikayetvar.app;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
    // You can keep this empty for most cases.
    // The FlutterActivity will handle the Flutter engine initialization.
}