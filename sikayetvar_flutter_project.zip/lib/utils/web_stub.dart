// This file provides stub implementations for platform-specific features
// that aren't available in web (dart:html) environment

export 'web_file.dart';