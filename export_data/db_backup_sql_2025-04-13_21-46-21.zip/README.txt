# ŞikayetVar Veritabanı Yedeği (sql format)

Tarih: 2025-04-13 21:46:27

Bu arşiv, veritabanının sql formatında yedeğini içerir.
İçerik:
- Tablo sayısı: 21
- Başarılı yedeklenen tablo sayısı: 21
