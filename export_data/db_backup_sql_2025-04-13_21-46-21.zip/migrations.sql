-- ŞikayetVar Veritabanı Yedeği
-- Tablo: migrations
-- Tarih: 2025-04-13 21:46:24

START TRANSACTION;

CREATE TABLE IF NOT EXISTS "migrations" (
  "id" integer NOT NULL DEFAULT nextval('migrations_id_seq'::regclass),
  "migration" character varying(255) NOT NULL,
  "batch" integer NOT NULL,
  PRIMARY KEY ("id")
);


COMMIT;
