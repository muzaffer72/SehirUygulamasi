# ŞikayetVar Veritabanı Tam Yedeği

Tarih: 2025-04-13 19:07:08

Bu arşiv, veritabanının tam bir yedeğini içerir.
İçerik:
- SQL dosyaları: 21
- JSON dosyaları: 21
- CSV dosyaları: 21
