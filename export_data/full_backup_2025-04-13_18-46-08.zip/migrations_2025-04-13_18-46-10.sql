CREATE TABLE IF NOT EXISTS migrations (
  id integer,
  migration character varying(255),
  batch integer
);

