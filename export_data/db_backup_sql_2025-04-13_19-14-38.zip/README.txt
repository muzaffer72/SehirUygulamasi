# ŞikayetVar Veritabanı Yedeği (sql format)

Tarih: 2025-04-13 19:14:43

Bu arşiv, veritabanının sql formatında yedeğini içerir.
İçerik:
- Tablo sayısı: 21
- Başarılı yedeklenen tablo sayısı: 21
